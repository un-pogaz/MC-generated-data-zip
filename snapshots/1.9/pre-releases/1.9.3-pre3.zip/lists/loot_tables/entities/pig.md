| Name               | Count | Chance | Weight | Comment       |
| ------------------ | ----- | ------ | ------ | ------------- |
| 1 time             |    -- |     -- |     -- |               |
| minecraft:porkchop |  1..3 |   100% |      1 | furnace smelt |