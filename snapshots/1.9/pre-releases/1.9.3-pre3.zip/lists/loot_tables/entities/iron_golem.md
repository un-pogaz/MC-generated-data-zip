| Name                 | Count | Chance | Weight | Comment |
| -------------------- | ----- | ------ | ------ | ------- |
| 1 time               |    -- |     -- |     -- |         |
| minecraft:red_flower |  0..2 |   100% |      1 |         |
| – – – – – – – – – –  | – – – | – – –  | – – –  | – – – – |
| 1 time               |    -- |     -- |     -- |         |
| minecraft:iron_ingot |  3..5 |   100% |      1 |         |