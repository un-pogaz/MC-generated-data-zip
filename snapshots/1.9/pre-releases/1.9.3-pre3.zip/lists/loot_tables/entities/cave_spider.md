| Name                 | Count | Chance | Weight | Comment          |
| -------------------- | ----- | ------ | ------ | ---------------- |
| 1 time               |    -- |     -- |     -- |                  |
| minecraft:string     |  0..2 |   100% |      1 |                  |
| – – – – – – – – – –  | – – – | – – –  | – – –  | – – – – – – – –  |
| 1 time               |    -- |     -- |     -- | killed by player |
| minecraft:spider_eye | -1..1 |   100% |      1 |                  |