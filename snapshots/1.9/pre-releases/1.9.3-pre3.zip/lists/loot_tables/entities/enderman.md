| Name                  | Count | Chance | Weight | Comment |
| --------------------- | ----- | ------ | ------ | ------- |
| 1 time                |    -- |     -- |     -- |         |
| minecraft:ender_pearl |  0..1 |   100% |      1 |         |