| Name                                 | Count | Chance | Weight | Comment |
| ------------------------------------ | ----- | ------ | ------ | ------- |
| 1 time                               |    -- |     -- |     -- |         |
| minecraft:wool                       |     1 |   100% |      1 |         |
| – – – – – – – – – – – – – – – – – –  | – – – | – – –  | – – –  | – – – – |
| 1 time                               |    -- |     -- |     -- |         |
| loot_table[]minecraft:entities/sheep |     1 |   100% |      1 |         |