| Name              | Count | Chance | Weight | Comment       |
| ----------------- | ----- | ------ | ------ | ------------- |
| 1 time            |    -- |     -- |     -- |               |
| minecraft:feather |  0..2 |   100% |      1 |               |
| – – – – – – – – – | – – – | – – –  | – – –  | – – – – – – – |
| 1 time            |    -- |     -- |     -- |               |
| minecraft:chicken |     1 |   100% |      1 | furnace smelt |