| Name            | Count | Chance | Weight | Comment |
| --------------- | ----- | ------ | ------ | ------- |
| 1 to 2 time     |    -- |     -- |     -- |         |
| minecraft:arrow |  2..7 |   100% |  30/30 |         |