| Name                   | Count | Chance | Weight | Comment |
| ---------------------- | ----- | ------ | ------ | ------- |
| 2 to 8 time            |    -- |     -- |     -- |         |
| minecraft:apple        |  1..3 |  23.8% |  15/63 |         |
| minecraft:coal         |  1..4 |  23.8% |  15/63 |         |
| minecraft:gold_nugget  |  1..3 |  15.9% |  10/63 |         |
| minecraft:stone_axe    |     1 |   3.2% |   2/63 |         |
| minecraft:rotten_flesh |     1 |  15.9% |  10/63 |         |
| minecraft:emerald      |     1 |   1.6% |   1/63 |         |
| minecraft:wheat        |  2..3 |  15.9% |  10/63 |         |
| – – – – – – – – – – –  | – – – | – – –  | – – –  | – – – – |
| 1 time                 |    -- |     -- |     -- |         |
| minecraft:golden_apple |     1 |   100% |      1 |         |